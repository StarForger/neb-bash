# README

A collection of useful bash functions
